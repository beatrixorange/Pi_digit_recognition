import numpy

# This is NOT a jupiter notebook. Make sure to open the .ipynb file 